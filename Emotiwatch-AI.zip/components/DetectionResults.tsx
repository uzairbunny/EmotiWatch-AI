
'use client';

interface Detection {
  id: string;
  object: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  timestamp: Date;
  type: 'safety' | 'suspicious' | 'normal' | 'device' | 'structure';
}

interface DetectionResultsProps {
  detections: Detection[];
}

export default function DetectionResults({ detections }: DetectionResultsProps) {
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'safety':
        return 'ri-shield-check-line text-green-600';
      case 'suspicious':
        return 'ri-alert-line text-red-600';
      case 'device':
        return 'ri-smartphone-line text-purple-600';
      case 'structure':
        return 'ri-building-line text-gray-600';
      default:
        return 'ri-eye-line text-blue-600';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'safety':
        return 'bg-green-50 border-green-200 text-green-800';
      case 'suspicious':
        return 'bg-red-50 border-red-200 text-red-800';
      case 'device':
        return 'bg-purple-50 border-purple-200 text-purple-800';
      case 'structure':
        return 'bg-gray-50 border-gray-200 text-gray-800';
      default:
        return 'bg-blue-50 border-blue-200 text-blue-800';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'safety':
        return 'Safety';
      case 'suspicious':
        return 'Alert';
      case 'device':
        return 'Device';
      case 'structure':
        return 'Structure';
      default:
        return 'Normal';
    }
  };

  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  const getObjectsByType = () => {
    const grouped = detections.reduce((acc, detection) => {
      const type = detection.type;
      if (!acc[type]) acc[type] = [];
      acc[type].push(detection);
      return acc;
    }, {} as Record<string, Detection[]>);

    return grouped;
  };

  const groupedDetections = getObjectsByType();

  return (
    <div className="space-y-3">
      {detections.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <i className="ri-search-line text-3xl mb-2"></i>
          <p>No detections yet</p>
          <p className="text-sm">Start detection to see all objects in view</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mb-4">
            {Object.entries(groupedDetections).map(([type, items]) => (
              <div key={type} className={`p-2 rounded-lg border text-center ${getTypeColor(type)}`}>
                <div className="text-lg font-bold">{items.length}</div>
                <div className="text-xs">{getTypeLabel(type)}</div>
              </div>
            ))}
          </div>

          <div className="max-h-80 overflow-y-auto">
            {detections.map((detection) => (
              <div
                key={detection.id}
                className={`border rounded-lg p-3 mb-2 ${getTypeColor(detection.type)}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 flex items-center justify-center">
                      <i className={`${getTypeIcon(detection.type)} text-lg`}></i>
                    </div>
                    <div>
                      <h4 className="font-medium">{detection.object}</h4>
                      <div className="flex items-center space-x-2 text-sm opacity-80">
                        <span>Confidence: {Math.round(detection.confidence * 100)}%</span>
                        <span>•</span>
                        <span>{getTypeLabel(detection.type)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-mono">
                      {formatTime(detection.timestamp)}
                    </p>
                    <p className="text-xs opacity-80">
                      ({detection.bbox.x}, {detection.bbox.y})
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
      
      {detections.length > 0 && (
        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
          <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
            <div>
              <strong>Total Objects:</strong> {detections.length}
            </div>
            <div>
              <strong>Unique Types:</strong> {Object.keys(groupedDetections).length}
            </div>
            <div>
              <strong>People:</strong> {detections.filter(d => d.object.toLowerCase().includes('person')).length}
            </div>
            <div>
              <strong>Devices:</strong> {detections.filter(d => d.type === 'device').length}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
