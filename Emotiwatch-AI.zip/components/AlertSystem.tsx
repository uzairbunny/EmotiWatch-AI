
'use client';

interface Alert {
  id: string;
  message: string;
  type: 'warning' | 'danger' | 'info';
  timestamp: Date;
}

interface AlertSystemProps {
  alerts: Alert[];
}

export default function AlertSystem({ alerts }: AlertSystemProps) {
  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'danger':
        return 'ri-error-warning-line';
      case 'warning':
        return 'ri-alert-line';
      case 'info':
        return 'ri-information-line';
      default:
        return 'ri-notification-line';
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'danger':
        return 'bg-red-50 border-red-200 text-red-800';
      case 'warning':
        return 'bg-yellow-50 border-yellow-200 text-yellow-800';
      case 'info':
        return 'bg-blue-50 border-blue-200 text-blue-800';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-800';
    }
  };

  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  return (
    <div className="space-y-3">
      {alerts.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <i className="ri-shield-check-line text-3xl mb-2"></i>
          <p>No alerts</p>
          <p className="text-sm">System monitoring normally</p>
        </div>
      ) : (
        <div className="max-h-64 overflow-y-auto">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`border rounded-lg p-3 ${getAlertColor(alert.type)}`}
            >
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 flex items-center justify-center">
                  <i className={`${getAlertIcon(alert.type)} text-lg`}></i>
                </div>
                <div className="flex-1">
                  <p className="font-medium">{alert.message}</p>
                  <p className="text-sm opacity-80 mt-1">
                    {formatTime(alert.timestamp)}
                  </p>
                </div>
                <button className="text-sm opacity-60 hover:opacity-100">
                  <i className="ri-close-line"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {alerts.length > 0 && (
        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
          <div className="flex justify-between text-sm text-gray-600">
            <span>Total alerts: {alerts.length}</span>
            <span>
              Critical: {alerts.filter(a => a.type === 'danger').length} | 
              Warnings: {alerts.filter(a => a.type === 'warning').length}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
