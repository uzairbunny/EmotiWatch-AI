
'use client';

import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <i className="ri-eye-line text-white"></i>
            </div>
            <h1 className="text-xl font-bold text-gray-900">SmartWatch AI</h1>
          </div>
          
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors">
              Dashboard
            </a>
            <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors">
              Analytics
            </a>
            <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors">
              Settings
            </a>
            <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors">
              Support
            </a>
          </nav>

          <div className="flex items-center space-x-4">
            <button className="p-2 text-gray-600 hover:text-gray-900 transition-colors">
              <i className="ri-notification-line text-xl"></i>
            </button>
            <button className="p-2 text-gray-600 hover:text-gray-900 transition-colors">
              <i className="ri-settings-line text-xl"></i>
            </button>
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <i className={`ri-${isMenuOpen ? 'close' : 'menu'}-line text-xl`}></i>
            </button>
          </div>
        </div>
        
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-2">
              <a href="#" className="px-4 py-2 text-gray-700 hover:bg-gray-50 rounded">
                Dashboard
              </a>
              <a href="#" className="px-4 py-2 text-gray-700 hover:bg-gray-50 rounded">
                Analytics
              </a>
              <a href="#" className="px-4 py-2 text-gray-700 hover:bg-gray-50 rounded">
                Settings
              </a>
              <a href="#" className="px-4 py-2 text-gray-700 hover:bg-gray-50 rounded">
                Support
              </a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
