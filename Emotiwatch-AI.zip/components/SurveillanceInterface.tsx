
'use client';

import { useState, useRef, useEffect } from 'react';
import VideoCapture from './VideoCapture';
import DetectionResults from './DetectionResults';
import DetectionControls from './DetectionControls';
import AlertSystem from './AlertSystem';

interface Detection {
  id: string;
  object: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  timestamp: Date;
  type: 'safety' | 'suspicious' | 'normal' | 'device' | 'structure';
}

interface Alert {
  id: string;
  message: string;
  type: 'warning' | 'danger' | 'info';
  timestamp: Date;
}

export default function SurveillanceInterface() {
  const [isDetecting, setIsDetecting] = useState(false);
  const [detections, setDetections] = useState<Detection[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [detectionMode, setDetectionMode] = useState<'construction' | 'security' | 'general'>('general');
  const [videoStream, setVideoStream] = useState<MediaStream | null>(null);
  const detectionIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const getMockDetections = () => {
    const baseDetections = [
      {
        id: '1',
        object: 'Person',
        confidence: 0.94,
        bbox: { x: 150, y: 100, width: 80, height: 150 },
        timestamp: new Date(),
        type: 'normal' as const
      },
      {
        id: '2',
        object: 'Mobile Phone',
        confidence: 0.87,
        bbox: { x: 200, y: 80, width: 30, height: 50 },
        timestamp: new Date(),
        type: 'device' as const
      },
      {
        id: '3',
        object: 'Wall',
        confidence: 0.98,
        bbox: { x: 10, y: 10, width: 100, height: 200 },
        timestamp: new Date(),
        type: 'structure' as const
      },
      {
        id: '4',
        object: 'Chair',
        confidence: 0.85,
        bbox: { x: 180, y: 200, width: 50, height: 80 },
        timestamp: new Date(),
        type: 'normal' as const
      },
      {
        id: '5',
        object: 'Laptop',
        confidence: 0.91,
        bbox: { x: 250, y: 160, width: 80, height: 50 },
        timestamp: new Date(),
        type: 'device' as const
      },
      {
        id: '6',
        object: 'Door',
        confidence: 0.89,
        bbox: { x: 320, y: 100, width: 50, height: 150 },
        timestamp: new Date(),
        type: 'structure' as const
      },
      {
        id: '7',
        object: 'Monitor',
        confidence: 0.92,
        bbox: { x: 170, y: 140, width: 60, height: 40 },
        timestamp: new Date(),
        type: 'device' as const
      },
      {
        id: '8',
        object: 'Bag',
        confidence: 0.86,
        bbox: { x: 250, y: 220, width: 40, height: 50 },
        timestamp: new Date(),
        type: 'normal' as const
      },
      {
        id: '9',
        object: 'Traffic Sign',
        confidence: 0.88,
        bbox: { x: 300, y: 50, width: 60, height: 40 },
        timestamp: new Date(),
        type: 'normal' as const
      },
      {
        id: '10',
        object: 'Keyboard',
        confidence: 0.83,
        bbox: { x: 175, y: 185, width: 50, height: 15 },
        timestamp: new Date(),
        type: 'device' as const
      }
    ];

    if (detectionMode === 'construction') {
      return [
        ...baseDetections,
        {
          id: '11',
          object: 'Safety Helmet',
          confidence: 0.95,
          bbox: { x: 120, y: 80, width: 60, height: 40 },
          timestamp: new Date(),
          type: 'safety' as const
        },
        {
          id: '12',
          object: 'Person without helmet',
          confidence: 0.78,
          bbox: { x: 300, y: 100, width: 80, height: 120 },
          timestamp: new Date(),
          type: 'suspicious' as const
        }
      ];
    } else if (detectionMode === 'security') {
      return [
        ...baseDetections,
        {
          id: '13',
          object: 'CCTV',
          confidence: 0.95,
          bbox: { x: 50, y: 20, width: 40, height: 30 },
          timestamp: new Date(),
          type: 'device' as const
        },
        {
          id: '14',
          object: 'Suspicious activity',
          confidence: 0.72,
          bbox: { x: 250, y: 80, width: 100, height: 120 },
          timestamp: new Date(),
          type: 'suspicious' as const
        }
      ];
    }

    return baseDetections;
  };

  const startDetection = () => {
    setIsDetecting(true);
    
    detectionIntervalRef.current = setInterval(() => {
      const availableDetections = getMockDetections();
      const randomCount = Math.floor(Math.random() * 4) + 2;
      const selectedDetections = [];
      
      for (let i = 0; i < randomCount; i++) {
        const randomDetection = availableDetections[Math.floor(Math.random() * availableDetections.length)];
        const newDetection: Detection = {
          ...randomDetection,
          id: `${Date.now()}-${i}`,
          timestamp: new Date(),
          bbox: {
            ...randomDetection.bbox,
            x: Math.random() * 400,
            y: Math.random() * 300
          }
        };
        selectedDetections.push(newDetection);
      }
      
      setDetections(prev => [...selectedDetections, ...prev.slice(0, 20)]);
      
      selectedDetections.forEach(detection => {
        if (detection.type === 'suspicious') {
          const alert: Alert = {
            id: `${Date.now()}-alert`,
            message: `${detection.object} detected with ${Math.round(detection.confidence * 100)}% confidence`,
            type: 'danger',
            timestamp: new Date()
          };
          setAlerts(prev => [alert, ...prev.slice(0, 4)]);
        }
      });
    }, 1500);
  };

  const stopDetection = () => {
    setIsDetecting(false);
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current);
    }
  };

  const clearDetections = () => {
    setDetections([]);
    setAlerts([]);
  };

  useEffect(() => {
    return () => {
      if (detectionIntervalRef.current) {
        clearInterval(detectionIntervalRef.current);
      }
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
        <DetectionControls
          isDetecting={isDetecting}
          detectionMode={detectionMode}
          onStart={startDetection}
          onStop={stopDetection}
          onClear={clearDetections}
          onModeChange={setDetectionMode}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Live Video Feed</h3>
          <VideoCapture
            isDetecting={isDetecting}
            detections={detections}
            onStreamReady={setVideoStream}
          />
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Detection Results</h3>
            <DetectionResults detections={detections} />
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Alert System</h3>
            <AlertSystem alerts={alerts} />
          </div>
        </div>
      </div>
    </div>
  );
}
