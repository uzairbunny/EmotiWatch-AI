'use client';

import { EmotionDetection } from './EmotionInterface';

interface EmotionResultsProps {
  detections: EmotionDetection[];
}

export default function EmotionResults({ detections }: EmotionResultsProps) {
  const getEmotionColor = (emotion: string) => {
    const colors: { [key: string]: string } = {
      happy: 'text-green-600 bg-green-50',
      sad: 'text-blue-600 bg-blue-50',
      angry: 'text-red-600 bg-red-50',
      surprised: 'text-yellow-600 bg-yellow-50',
      fearful: 'text-purple-600 bg-purple-50',
      disgusted: 'text-lime-600 bg-lime-50',
      neutral: 'text-gray-600 bg-gray-50'
    };
    return colors[emotion] || 'text-gray-600 bg-gray-50';
  };

  const getEmotionIcon = (emotion: string) => {
    const icons: { [key: string]: string } = {
      happy: 'ri-emotion-happy-line',
      sad: 'ri-emotion-sad-line',
      angry: 'ri-emotion-angry-line',
      surprised: 'ri-emotion-2-line',
      fearful: 'ri-emotion-scared-line',
      disgusted: 'ri-emotion-unhappy-line',
      neutral: 'ri-emotion-normal-line'
    };
    return icons[emotion] || 'ri-emotion-normal-line';
  };

  if (detections.length === 0) {
    return (
      <div className="text-center py-12">
        <i className="ri-emotion-line text-4xl text-gray-300 mb-4"></i>
        <p className="text-gray-500">No emotions detected yet</p>
        <p className="text-sm text-gray-400 mt-1">Start detection to see live results</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 max-h-96 overflow-y-auto">
      {detections.slice(0, 20).map((detection) => (
        <div
          key={detection.id}
          className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getEmotionColor(detection.dominantEmotion)}`}>
                <i className={`${getEmotionIcon(detection.dominantEmotion)} text-sm`}></i>
              </div>
              <div>
                <h4 className="font-medium text-gray-900 capitalize">
                  {detection.dominantEmotion}
                </h4>
                <p className="text-xs text-gray-500">
                  {Math.round(detection.confidence * 100)}% confidence
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-500">
                {detection.timestamp.toLocaleTimeString()}
              </p>
              <p className="text-xs text-gray-400">
                Face #{detection.faceId.split('-')[1]}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <h5 className="text-sm font-medium text-gray-700">All Emotions:</h5>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(detection.emotions).map(([emotion, value]) => (
                <div key={emotion} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <i className={`${getEmotionIcon(emotion)} text-xs ${getEmotionColor(emotion)}`}></i>
                    <span className="text-xs text-gray-600 capitalize">{emotion}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-12 h-1 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-purple-400 to-purple-600 rounded-full"
                        style={{ width: `${value * 100}%` }}
                      />
                    </div>
                    <span className="text-xs text-gray-500 w-8 text-right">
                      {Math.round(value * 100)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}