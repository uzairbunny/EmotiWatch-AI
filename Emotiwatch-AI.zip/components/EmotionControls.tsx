'use client';

interface EmotionControlsProps {
  isDetecting: boolean;
  detectionMode: 'realtime' | 'analysis' | 'monitoring';
  onStart: () => void;
  onStop: () => void;
  onClear: () => void;
  onModeChange: (mode: 'realtime' | 'analysis' | 'monitoring') => void;
}

export default function EmotionControls({
  isDetecting,
  detectionMode,
  onStart,
  onStop,
  onClear,
  onModeChange
}: EmotionControlsProps) {
  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between space-y-4 sm:space-y-0">
      <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
        <h2 className="text-lg font-semibold text-gray-900">
          Emotion Detection Controls
        </h2>
        
        <div className="flex items-center space-x-2 bg-gray-100 rounded-lg p-1">
          <button
            onClick={() => onModeChange('realtime')}
            className={`px-3 py-1 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${
              detectionMode === 'realtime'
                ? 'bg-purple-500 text-white'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <i className="ri-eye-line mr-1"></i>
            Real-time
          </button>
          <button
            onClick={() => onModeChange('analysis')}
            className={`px-3 py-1 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${
              detectionMode === 'analysis'
                ? 'bg-purple-500 text-white'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <i className="ri-bar-chart-line mr-1"></i>
            Analysis
          </button>
          <button
            onClick={() => onModeChange('monitoring')}
            className={`px-3 py-1 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${
              detectionMode === 'monitoring'
                ? 'bg-purple-500 text-white'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <i className="ri-monitor-line mr-1"></i>
            Monitoring
          </button>
        </div>
      </div>

      <div className="flex items-center space-x-3">
        <button
          onClick={isDetecting ? onStop : onStart}
          className={`flex items-center px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
            isDetecting
              ? 'bg-red-500 hover:bg-red-600 text-white'
              : 'bg-purple-500 hover:bg-purple-600 text-white'
          }`}
        >
          <i className={`${isDetecting ? 'ri-stop-line' : 'ri-play-line'} mr-2`}></i>
          {isDetecting ? 'Stop Detection' : 'Start Detection'}
        </button>
        
        <button
          onClick={onClear}
          className="flex items-center px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors whitespace-nowrap"
        >
          <i className="ri-delete-bin-line mr-2"></i>
          Clear
        </button>
      </div>
    </div>
  );
}