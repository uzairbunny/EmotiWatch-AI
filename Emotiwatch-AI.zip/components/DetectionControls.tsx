
'use client';

interface DetectionControlsProps {
  isDetecting: boolean;
  detectionMode: 'construction' | 'security' | 'general';
  onStart: () => void;
  onStop: () => void;
  onClear: () => void;
  onModeChange: (mode: 'construction' | 'security' | 'general') => void;
}

export default function DetectionControls({
  isDetecting,
  detectionMode,
  onStart,
  onStop,
  onClear,
  onModeChange
}: DetectionControlsProps) {
  const detectionModes = [
    { 
      id: 'general', 
      name: 'General Detection', 
      description: 'Detect everything: people, devices, objects, structures',
      icon: 'ri-eye-line'
    },
    { 
      id: 'construction', 
      name: 'Construction Safety', 
      description: 'All objects + safety equipment monitoring',
      icon: 'ri-hard-hat-line'
    },
    { 
      id: 'security', 
      name: 'Security Monitoring', 
      description: 'All objects + suspicious activity detection',
      icon: 'ri-shield-line'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Detection Controls</h3>
        <div className="flex space-x-2">
          {!isDetecting ? (
            <button
              onClick={onStart}
              className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors whitespace-nowrap"
            >
              <i className="ri-play-line mr-2"></i>
              Start Detection
            </button>
          ) : (
            <button
              onClick={onStop}
              className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors whitespace-nowrap"
            >
              <i className="ri-stop-line mr-2"></i>
              Stop Detection
            </button>
          )}
          <button
            onClick={onClear}
            className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors whitespace-nowrap"
          >
            <i className="ri-delete-bin-line mr-2"></i>
            Clear Results
          </button>
        </div>
      </div>

      <div>
        <h4 className="text-sm font-medium text-gray-700 mb-3">Detection Mode</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {detectionModes.map((mode) => (
            <button
              key={mode.id}
              onClick={() => onModeChange(mode.id as 'construction' | 'security' | 'general')}
              className={`p-4 rounded-lg border-2 transition-all text-left ${
                detectionMode === mode.id
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center mb-2">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                  detectionMode === mode.id ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-600'
                }`}>
                  <i className={`${mode.icon} text-sm`}></i>
                </div>
                <h5 className="font-medium text-gray-900">{mode.name}</h5>
              </div>
              <p className="text-sm text-gray-600">{mode.description}</p>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="text-sm font-medium text-gray-700 mb-3">Detectable Objects</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
          <div className="bg-white p-2 rounded border">
            <i className="ri-user-line text-blue-500 mr-1"></i>
            <span>People</span>
          </div>
          <div className="bg-white p-2 rounded border">
            <i className="ri-smartphone-line text-green-500 mr-1"></i>
            <span>Devices</span>
          </div>
          <div className="bg-white p-2 rounded border">
            <i className="ri-building-line text-purple-500 mr-1"></i>
            <span>Structures</span>
          </div>
          <div className="bg-white p-2 rounded border">
            <i className="ri-car-line text-orange-500 mr-1"></i>
            <span>Vehicles</span>
          </div>
          <div className="bg-white p-2 rounded border">
            <i className="ri-road-map-line text-red-500 mr-1"></i>
            <span>Signs</span>
          </div>
          <div className="bg-white p-2 rounded border">
            <i className="ri-armchair-line text-indigo-500 mr-1"></i>
            <span>Furniture</span>
          </div>
          <div className="bg-white p-2 rounded border">
            <i className="ri-shopping-bag-line text-pink-500 mr-1"></i>
            <span>Objects</span>
          </div>
          <div className="bg-white p-2 rounded border">
            <i className="ri-shield-check-line text-yellow-500 mr-1"></i>
            <span>Safety</span>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="text-sm font-medium text-gray-700 mb-2">System Status</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className={`w-3 h-3 rounded-full mx-auto mb-1 ${
              isDetecting ? 'bg-green-500' : 'bg-gray-400'
            }`}></div>
            <span className="text-xs text-gray-600">Detection</span>
          </div>
          <div className="text-center">
            <div className="w-3 h-3 rounded-full bg-green-500 mx-auto mb-1"></div>
            <span className="text-xs text-gray-600">Camera</span>
          </div>
          <div className="text-center">
            <div className="w-3 h-3 rounded-full bg-green-500 mx-auto mb-1"></div>
            <span className="text-xs text-gray-600">AI Model</span>
          </div>
          <div className="text-center">
            <div className="w-3 h-3 rounded-full bg-green-500 mx-auto mb-1"></div>
            <span className="text-xs text-gray-600">Alerts</span>
          </div>
        </div>
      </div>
    </div>
  );
}
