
'use client';

import { useRef, useEffect, useState } from 'react';
import { EmotionDetection, FaceDetectionState } from './EmotionInterface';

interface EmotionVideoCaptureProps {
  isDetecting: boolean;
  detections: EmotionDetection[];
  currentFace: FaceDetectionState;
  processingStep: 'detecting' | 'analyzing' | 'complete';
  onStreamReady: (stream: MediaStream | null) => void;
}

export default function EmotionVideoCapture({ 
  isDetecting, 
  detections, 
  currentFace, 
  processingStep, 
  onStreamReady 
}: EmotionVideoCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hasCamera, setHasCamera] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setHasCamera(true);
        setCameraError(null);
        onStreamReady(stream);
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      setCameraError('Unable to access camera. Please check permissions.');
      setHasCamera(false);
      onStreamReady(null);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      onStreamReady(null);
    }
  };

  const getEmotionColor = (emotion: string) => {
    const colors: { [key: string]: string } = {
      happy: '#10b981',
      sad: '#3b82f6',
      angry: '#ef4444',
      surprised: '#f59e0b',
      fearful: '#8b5cf6',
      disgusted: '#84cc16',
      neutral: '#6b7280'
    };
    return colors[emotion] || '#6b7280';
  };

  const getProcessingColor = () => {
    switch (processingStep) {
      case 'detecting': return '#3b82f6';
      case 'analyzing': return '#f59e0b';
      case 'complete': return '#10b981';
      default: return '#6b7280';
    }
  };

  const getProcessingLabel = () => {
    switch (processingStep) {
      case 'detecting': return 'Detecting Face...';
      case 'analyzing': return 'Analyzing Emotions...';
      case 'complete': return 'Analysis Complete';
      default: return 'Standby';
    }
  };

  const drawDetections = () => {
    if (!canvasRef.current || !videoRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (isDetecting) {
      // Draw current face detection
      if (currentFace.isDetected && currentFace.bbox) {
        const { bbox } = currentFace;
        const color = getProcessingColor();
        
        // Draw face bounding box
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.strokeRect(bbox.x, bbox.y, bbox.width, bbox.height);
        
        // Draw processing status
        const labelText = getProcessingLabel();
        ctx.font = '14px Arial';
        const textWidth = ctx.measureText(labelText).width;
        
        ctx.fillStyle = color;
        ctx.fillRect(bbox.x, bbox.y - 30, textWidth + 20, 30);
        
        ctx.fillStyle = 'white';
        ctx.fillText(labelText, bbox.x + 10, bbox.y - 10);
        
        // Draw confidence bar for face detection
        const barWidth = bbox.width;
        const barHeight = 6;
        const barX = bbox.x;
        const barY = bbox.y + bbox.height + 5;
        
        ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        ctx.fillRect(barX, barY, barWidth, barHeight);
        
        ctx.fillStyle = color;
        ctx.fillRect(barX, barY, barWidth * currentFace.confidence, barHeight);
      }
      
      // Draw emotion results for completed analysis
      if (processingStep === 'complete' && detections.length > 0) {
        const latestDetection = detections[0];
        const { bbox, dominantEmotion, confidence } = latestDetection;
        const emotionColor = getEmotionColor(dominantEmotion);
        
        // Draw emotion label
        const emotionText = `${dominantEmotion} (${Math.round(confidence * 100)}%)`;
        ctx.font = '16px Arial';
        const emotionTextWidth = ctx.measureText(emotionText).width;
        
        ctx.fillStyle = emotionColor;
        ctx.fillRect(bbox.x, bbox.y - 60, emotionTextWidth + 20, 25);
        
        ctx.fillStyle = 'white';
        ctx.fillText(emotionText, bbox.x + 10, bbox.y - 40);
        
        // Draw all emotion scores
        const emotions = Object.entries(latestDetection.emotions);
        emotions.forEach(([emotion, score], index) => {
          const barY = bbox.y + bbox.height + 15 + (index * 20);
          const barWidth = bbox.width * 0.8;
          const fillWidth = barWidth * score;
          
          ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
          ctx.fillRect(bbox.x, barY, barWidth, 15);
          
          ctx.fillStyle = getEmotionColor(emotion);
          ctx.fillRect(bbox.x, barY, fillWidth, 15);
          
          ctx.fillStyle = '#000';
          ctx.font = '12px Arial';
          ctx.fillText(`${emotion}: ${Math.round(score * 100)}%`, bbox.x + barWidth + 10, barY + 12);
        });
      }
    }
  };

  useEffect(() => {
    drawDetections();
  }, [currentFace, processingStep, detections, isDetecting]);

  return (
    <div className="relative">
      <div className="relative bg-gray-900 rounded-lg overflow-hidden">
        {cameraError ? (
          <div className="w-full h-96 flex items-center justify-center bg-gray-800 text-white">
            <div className="text-center">
              <i className="ri-camera-off-line text-4xl mb-3"></i>
              <p className="text-lg mb-2">Camera Access Required</p>
              <p className="text-sm text-gray-400 mb-4">{cameraError}</p>
              <button
                onClick={startCamera}
                className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <i className="ri-refresh-line mr-2"></i>
                Retry Camera Access
              </button>
            </div>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-96 object-cover"
              onLoadedMetadata={() => {
                if (canvasRef.current && videoRef.current) {
                  canvasRef.current.width = videoRef.current.videoWidth;
                  canvasRef.current.height = videoRef.current.videoHeight;
                }
              }}
            />
            <canvas
              ref={canvasRef}
              className="absolute top-0 left-0 w-full h-full pointer-events-none"
            />
          </>
        )}
        
        <div className="absolute top-4 right-4 flex items-center space-x-2">
          <div className={`flex items-center px-3 py-1 rounded-full text-sm font-medium ${
            isDetecting 
              ? 'bg-purple-500 text-white' 
              : 'bg-gray-500 text-white'
          }`}>
            <div className={`w-2 h-2 rounded-full mr-2 ${
              isDetecting ? 'bg-white animate-pulse' : 'bg-gray-300'
            }`} />
            {isDetecting ? getProcessingLabel() : 'Standby'}
          </div>
          
          {isDetecting && currentFace.isDetected && (
            <div className="bg-black/50 text-white px-3 py-1 rounded-full text-sm">
              Face detected ({Math.round(currentFace.confidence * 100)}%)
            </div>
          )}
        </div>
        
        {/* Processing Steps Indicator */}
        {isDetecting && (
          <div className="absolute bottom-4 left-4 flex items-center space-x-4 bg-black/50 text-white px-4 py-2 rounded-lg">
            <div className={`flex items-center ${processingStep === 'detecting' ? 'text-blue-400' : 'text-gray-400'}`}>
              <div className={`w-2 h-2 rounded-full mr-2 ${processingStep === 'detecting' ? 'bg-blue-400 animate-pulse' : 'bg-gray-400'}`} />
              <span className="text-sm">1. Face Detection</span>
            </div>
            <div className={`flex items-center ${processingStep === 'analyzing' ? 'text-yellow-400' : 'text-gray-400'}`}>
              <div className={`w-2 h-2 rounded-full mr-2 ${processingStep === 'analyzing' ? 'bg-yellow-400 animate-pulse' : 'bg-gray-400'}`} />
              <span className="text-sm">2. Emotion Analysis</span>
            </div>
            <div className={`flex items-center ${processingStep === 'complete' ? 'text-green-400' : 'text-gray-400'}`}>
              <div className={`w-2 h-2 rounded-full mr-2 ${processingStep === 'complete' ? 'bg-green-400' : 'bg-gray-400'}`} />
              <span className="text-sm">3. Results</span>
            </div>
          </div>
        )}
      </div>
      
      <div className="mt-4 text-center">
        <p className="text-sm text-gray-600">
          {hasCamera 
            ? 'Camera active - Sequential face detection and emotion analysis' 
            : 'Camera access required for emotion detection'
          }
        </p>
      </div>
    </div>
  );
}
