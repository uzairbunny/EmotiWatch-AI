
'use client';

import { useState, useRef, useEffect } from 'react';
import EmotionVideoCapture from './EmotionVideoCapture';
import EmotionResults from './EmotionResults';
import EmotionControls from './EmotionControls';
import EmotionAnalytics from './EmotionAnalytics';

export interface EmotionDetection {
  id: string;
  faceId: string;
  emotions: {
    happy: number;
    sad: number;
    angry: number;
    surprised: number;
    fearful: number;
    disgusted: number;
    neutral: number;
  };
  dominantEmotion: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  timestamp: Date;
}

export interface FaceDetectionState {
  isDetected: boolean;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  } | null;
  confidence: number;
}

export default function EmotionInterface() {
  const [isDetecting, setIsDetecting] = useState(false);
  const [detections, setDetections] = useState<EmotionDetection[]>([]);
  const [detectionMode, setDetectionMode] = useState<'realtime' | 'analysis' | 'monitoring'>('realtime');
  const [videoStream, setVideoStream] = useState<MediaStream | null>(null);
  const [currentFace, setCurrentFace] = useState<FaceDetectionState>({ isDetected: false, bbox: null, confidence: 0 });
  const [processingStep, setProcessingStep] = useState<'detecting' | 'analyzing' | 'complete'>('detecting');
  const detectionIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const detectFace = (): FaceDetectionState => {
    // Simulate face detection
    const faceDetected = Math.random() > 0.3; // 70% chance of detecting face
    
    if (faceDetected) {
      return {
        isDetected: true,
        bbox: {
          x: 200 + Math.random() * 200,
          y: 100 + Math.random() * 150,
          width: 150 + Math.random() * 50,
          height: 180 + Math.random() * 60
        },
        confidence: 0.8 + Math.random() * 0.2
      };
    }
    
    return { isDetected: false, bbox: null, confidence: 0 };
  };

  const analyzeEmotions = (faceData: FaceDetectionState): EmotionDetection | null => {
    if (!faceData.isDetected || !faceData.bbox) return null;

    const emotions = {
      happy: Math.random() * 0.8 + 0.1,
      sad: Math.random() * 0.6 + 0.05,
      angry: Math.random() * 0.5 + 0.05,
      surprised: Math.random() * 0.4 + 0.05,
      fearful: Math.random() * 0.3 + 0.02,
      disgusted: Math.random() * 0.3 + 0.02,
      neutral: Math.random() * 0.7 + 0.1
    };

    // Normalize emotions to sum to 1
    const total = Object.values(emotions).reduce((sum, val) => sum + val, 0);
    Object.keys(emotions).forEach(key => {
      emotions[key as keyof typeof emotions] /= total;
    });

    const dominantEmotion = Object.entries(emotions).reduce((a, b) => 
      emotions[a[0] as keyof typeof emotions] > emotions[b[0] as keyof typeof emotions] ? a : b
    )[0];

    return {
      id: `emotion-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      faceId: 'primary-face',
      emotions,
      dominantEmotion,
      confidence: emotions[dominantEmotion as keyof typeof emotions],
      bbox: faceData.bbox,
      timestamp: new Date()
    };
  };

  const processDetection = async () => {
    // Step 1: Detect face
    setProcessingStep('detecting');
    const faceData = detectFace();
    setCurrentFace(faceData);

    if (!faceData.isDetected) {
      setProcessingStep('detecting');
      return;
    }

    // Step 2: Analyze emotions for detected face
    setProcessingStep('analyzing');
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate processing time
    
    const emotionResult = analyzeEmotions(faceData);
    if (emotionResult) {
      setDetections(prev => [emotionResult, ...prev.slice(0, 49)]);
    }

    setProcessingStep('complete');
    
    // Reset after a short delay
    setTimeout(() => {
      setProcessingStep('detecting');
    }, 1000);
  };

  const startDetection = () => {
    setIsDetecting(true);
    
    detectionIntervalRef.current = setInterval(() => {
      processDetection();
    }, 2000); // Process every 2 seconds for better visualization
  };

  const stopDetection = () => {
    setIsDetecting(false);
    setProcessingStep('detecting');
    setCurrentFace({ isDetected: false, bbox: null, confidence: 0 });
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current);
    }
  };

  const clearDetections = () => {
    setDetections([]);
    setCurrentFace({ isDetected: false, bbox: null, confidence: 0 });
    setProcessingStep('detecting');
  };

  useEffect(() => {
    return () => {
      if (detectionIntervalRef.current) {
        clearInterval(detectionIntervalRef.current);
      }
    };
  }, []);

  return (
    <div className="max-w-7xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
        <EmotionControls
          isDetecting={isDetecting}
          detectionMode={detectionMode}
          onStart={startDetection}
          onStop={stopDetection}
          onClear={clearDetections}
          onModeChange={setDetectionMode}
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2">
          <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <i className="ri-camera-line mr-2"></i>
              Live Video Feed
            </h3>
            <EmotionVideoCapture
              isDetecting={isDetecting}
              detections={detections}
              currentFace={currentFace}
              processingStep={processingStep}
              onStreamReady={setVideoStream}
            />
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <i className="ri-bar-chart-line mr-2"></i>
              Emotion Analytics
            </h3>
            <EmotionAnalytics detections={detections} />
          </div>
        </div>

        <div className="xl:col-span-1">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <i className="ri-emotion-line mr-2"></i>
              Detection Results
            </h3>
            <EmotionResults detections={detections} />
          </div>
        </div>
      </div>
    </div>
  );
}
