
'use client';

import { useRef, useEffect, useState } from 'react';

interface Detection {
  id: string;
  object: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  timestamp: Date;
  type: 'safety' | 'suspicious' | 'normal';
}

interface VideoCaptureProps {
  isDetecting: boolean;
  detections: Detection[];
  onStreamReady: (stream: MediaStream | null) => void;
}

export default function VideoCapture({ isDetecting, detections, onStreamReady }: VideoCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hasCamera, setHasCamera] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setHasCamera(true);
        setCameraError(null);
        onStreamReady(stream);
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      setCameraError('Unable to access camera. Please check permissions.');
      setHasCamera(false);
      onStreamReady(null);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      onStreamReady(null);
    }
  };

  const drawDetections = () => {
    if (!canvasRef.current || !videoRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (isDetecting && detections.length > 0) {
      detections.slice(0, 3).forEach(detection => {
        const { bbox, object, confidence, type } = detection;
        
        const color = type === 'safety' ? '#10b981' : type === 'suspicious' ? '#ef4444' : '#3b82f6';
        
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.strokeRect(bbox.x, bbox.y, bbox.width, bbox.height);
        
        ctx.fillStyle = color;
        ctx.fillRect(bbox.x, bbox.y - 25, bbox.width, 25);
        
        ctx.fillStyle = 'white';
        ctx.font = '12px Arial';
        ctx.fillText(
          `${object} (${Math.round(confidence * 100)}%)`,
          bbox.x + 5,
          bbox.y - 8
        );
      });
    }
  };

  useEffect(() => {
    drawDetections();
  }, [detections, isDetecting]);

  return (
    <div className="relative">
      <div className="relative bg-gray-900 rounded-lg overflow-hidden">
        {cameraError ? (
          <div className="w-full h-80 flex items-center justify-center bg-gray-800 text-white">
            <div className="text-center">
              <i className="ri-camera-off-line text-4xl mb-2"></i>
              <p className="text-sm">{cameraError}</p>
              <button
                onClick={startCamera}
                className="mt-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
              >
                Retry Camera Access
              </button>
            </div>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-80 object-cover"
              onLoadedMetadata={() => {
                if (canvasRef.current && videoRef.current) {
                  canvasRef.current.width = videoRef.current.videoWidth;
                  canvasRef.current.height = videoRef.current.videoHeight;
                }
              }}
            />
            <canvas
              ref={canvasRef}
              className="absolute top-0 left-0 w-full h-full pointer-events-none"
            />
          </>
        )}
        
        <div className="absolute top-4 right-4">
          <div className={`flex items-center px-3 py-1 rounded-full text-sm font-medium ${
            isDetecting 
              ? 'bg-red-500 text-white' 
              : 'bg-gray-500 text-white'
          }`}>
            <div className={`w-2 h-2 rounded-full mr-2 ${
              isDetecting ? 'bg-white animate-pulse' : 'bg-gray-300'
            }`} />
            {isDetecting ? 'Detecting' : 'Standby'}
          </div>
        </div>
      </div>
      
      <div className="mt-4 text-center">
        <p className="text-sm text-gray-600">
          {hasCamera 
            ? 'Camera active - AI detection ready' 
            : 'No camera detected - using demo mode'
          }
        </p>
      </div>
    </div>
  );
}
