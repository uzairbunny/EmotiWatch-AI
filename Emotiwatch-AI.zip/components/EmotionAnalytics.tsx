'use client';

import { useMemo } from 'react';
import { EmotionDetection } from './EmotionInterface';

interface EmotionAnalyticsProps {
  detections: EmotionDetection[];
}

export default function EmotionAnalytics({ detections }: EmotionAnalyticsProps) {
  const analytics = useMemo(() => {
    if (detections.length === 0) return null;

    const recentDetections = detections.slice(0, 50);
    const emotionCounts: { [key: string]: number } = {};
    const emotionTotals: { [key: string]: number } = {};
    
    recentDetections.forEach(detection => {
      emotionCounts[detection.dominantEmotion] = (emotionCounts[detection.dominantEmotion] || 0) + 1;
      
      Object.entries(detection.emotions).forEach(([emotion, value]) => {
        emotionTotals[emotion] = (emotionTotals[emotion] || 0) + value;
      });
    });

    const totalDetections = recentDetections.length;
    const averageEmotions = Object.entries(emotionTotals).map(([emotion, total]) => ({
      emotion,
      percentage: (total / totalDetections) * 100
    })).sort((a, b) => b.percentage - a.percentage);

    const dominantEmotions = Object.entries(emotionCounts).map(([emotion, count]) => ({
      emotion,
      count,
      percentage: (count / totalDetections) * 100
    })).sort((a, b) => b.count - a.count);

    const avgConfidence = recentDetections.reduce((sum, d) => sum + d.confidence, 0) / totalDetections;

    return {
      totalDetections,
      averageEmotions,
      dominantEmotions,
      avgConfidence: avgConfidence * 100
    };
  }, [detections]);

  const getEmotionColor = (emotion: string) => {
    const colors: { [key: string]: string } = {
      happy: 'bg-green-500',
      sad: 'bg-blue-500',
      angry: 'bg-red-500',
      surprised: 'bg-yellow-500',
      fearful: 'bg-purple-500',
      disgusted: 'bg-lime-500',
      neutral: 'bg-gray-500'
    };
    return colors[emotion] || 'bg-gray-500';
  };

  const getEmotionIcon = (emotion: string) => {
    const icons: { [key: string]: string } = {
      happy: 'ri-emotion-happy-line',
      sad: 'ri-emotion-sad-line',
      angry: 'ri-emotion-angry-line',
      surprised: 'ri-emotion-2-line',
      fearful: 'ri-emotion-scared-line',
      disgusted: 'ri-emotion-unhappy-line',
      neutral: 'ri-emotion-normal-line'
    };
    return icons[emotion] || 'ri-emotion-normal-line';
  };

  if (!analytics) {
    return (
      <div className="text-center py-12">
        <i className="ri-bar-chart-line text-4xl text-gray-300 mb-4"></i>
        <p className="text-gray-500">No data available for analysis</p>
        <p className="text-sm text-gray-400 mt-1">Start emotion detection to generate analytics</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Detections</p>
              <p className="text-2xl font-bold text-gray-900">{analytics.totalDetections}</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
              <i className="ri-user-line text-purple-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-50 to-teal-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Average Confidence</p>
              <p className="text-2xl font-bold text-gray-900">{analytics.avgConfidence.toFixed(1)}%</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <i className="ri-check-line text-green-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Top Emotion</p>
              <p className="text-2xl font-bold text-gray-900 capitalize">
                {analytics.dominantEmotions[0]?.emotion || 'None'}
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
              <i className={`${getEmotionIcon(analytics.dominantEmotions[0]?.emotion || 'neutral')} text-orange-600 text-xl`}></i>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Emotion Distribution</h4>
          <div className="space-y-3">
            {analytics.averageEmotions.slice(0, 7).map((item) => (
              <div key={item.emotion} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-4 h-4 rounded-full ${getEmotionColor(item.emotion)}`}></div>
                  <span className="text-sm font-medium text-gray-700 capitalize">{item.emotion}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${getEmotionColor(item.emotion)} rounded-full`}
                      style={{ width: `${Math.min(item.percentage, 100)}%` }}
                    />
                  </div>
                  <span className="text-sm text-gray-600 w-12 text-right">
                    {item.percentage.toFixed(1)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-4">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Detection Summary</h4>
          <div className="space-y-3">
            {analytics.dominantEmotions.slice(0, 5).map((item) => (
              <div key={item.emotion} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <i className={`${getEmotionIcon(item.emotion)} text-lg text-gray-600`}></i>
                  <div>
                    <p className="text-sm font-medium text-gray-900 capitalize">{item.emotion}</p>
                    <p className="text-xs text-gray-500">{item.count} detections</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-gray-900">{item.percentage.toFixed(1)}%</p>
                  <p className="text-xs text-gray-500">of total</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}