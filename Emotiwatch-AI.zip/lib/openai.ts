const OPENAI_API_KEY = 'your-openai-api-key-here';

export async function translateWithOpenAI(text: string, sourceLang: string, targetLang: string): Promise<string> {
  if (!OPENAI_API_KEY || OPENAI_API_KEY === 'your-openai-api-key-here') {
    throw new Error('OpenAI API key not configured');
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: `You are a professional medical translator. Translate the following text from ${sourceLang} to ${targetLang}. Ensure medical terminology is accurately translated. If the text contains medical terms, prioritize clinical accuracy. Return only the translated text without any additional commentary.`
          },
          {
            role: 'user',
            content: text
          }
        ],
        max_tokens: 500,
        temperature: 0.3
      }),
    });

    if (!response.ok) {
      throw new Error('OpenAI API request failed');
    }

    const data = await response.json();
    return data.choices[0].message.content.trim();
  } catch (error) {
    console.error('OpenAI translation error:', error);
    throw error;
  }
}