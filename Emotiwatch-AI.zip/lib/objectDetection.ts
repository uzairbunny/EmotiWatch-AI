
export interface DetectionResult {
  object: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  type: 'safety' | 'suspicious' | 'normal' | 'device' | 'structure';
}

export const constructionSafetyModel = {
  classes: [
    'Person', 'Mobile Phone', 'Laptop', 'Tablet', 'Wall', 'Door', 'Window',
    'Safety Helmet', 'Safety Vest', 'Hard Hat', 'Safety Goggles', 'Safety Boots',
    'Person without helmet', 'Unsafe behavior', 'Construction worker', 'Safety barrier',
    'Traffic Sign', 'Warning Sign', 'Stop Sign', 'Construction Sign', 'Exit Sign',
    'Chair', 'Table', 'Desk', 'Monitor', 'Keyboard', 'Mouse', 'Backpack', 'Bag',
    'Car', 'Truck', 'Van', 'Motorcycle', 'Bicycle', 'Tools', 'Ladder', 'Crane',
    'Building', 'Pillar', 'Ceiling', 'Floor', 'Stairs', 'Elevator', 'Fire Extinguisher'
  ],
  
  detectObjects: (imageData: ImageData): DetectionResult[] => {
    const mockDetections: DetectionResult[] = [
      {
        object: 'Person',
        confidence: 0.94,
        bbox: { x: 150, y: 100, width: 80, height: 150 },
        type: 'normal'
      },
      {
        object: 'Mobile Phone',
        confidence: 0.87,
        bbox: { x: 200, y: 80, width: 30, height: 50 },
        type: 'device'
      },
      {
        object: 'Safety Helmet',
        confidence: 0.95,
        bbox: { x: 120, y: 80, width: 60, height: 40 },
        type: 'safety'
      },
      {
        object: 'Wall',
        confidence: 0.98,
        bbox: { x: 10, y: 10, width: 100, height: 200 },
        type: 'structure'
      },
      {
        object: 'Warning Sign',
        confidence: 0.91,
        bbox: { x: 300, y: 50, width: 80, height: 60 },
        type: 'normal'
      },
      {
        object: 'Person without helmet',
        confidence: 0.88,
        bbox: { x: 350, y: 120, width: 70, height: 140 },
        type: 'suspicious'
      },
      {
        object: 'Laptop',
        confidence: 0.85,
        bbox: { x: 250, y: 180, width: 60, height: 40 },
        type: 'device'
      },
      {
        object: 'Chair',
        confidence: 0.82,
        bbox: { x: 180, y: 200, width: 50, height: 80 },
        type: 'normal'
      },
      {
        object: 'Door',
        confidence: 0.89,
        bbox: { x: 50, y: 50, width: 40, height: 120 },
        type: 'structure'
      },
      {
        object: 'Construction Sign',
        confidence: 0.93,
        bbox: { x: 280, y: 30, width: 70, height: 50 },
        type: 'normal'
      }
    ];
    
    return mockDetections.map(detection => ({
      ...detection,
      bbox: {
        ...detection.bbox,
        x: Math.random() * (imageData.width - detection.bbox.width),
        y: Math.random() * (imageData.height - detection.bbox.height)
      }
    }));
  }
};

export const securityModel = {
  classes: [
    'Person', 'Mobile Phone', 'Laptop', 'Tablet', 'Camera', 'CCTV', 'Wall', 'Door', 'Window',
    'Vehicle', 'Car', 'Motorcycle', 'Bicycle', 'Truck', 'Bus', 'Van',
    'Suspicious activity', 'Weapon', 'Knife', 'Gun', 'Abandoned object', 'Bag', 'Backpack',
    'Crowd gathering', 'Intruder', 'Emergency vehicle', 'Police car', 'Ambulance',
    'Traffic Sign', 'Stop Sign', 'No Entry Sign', 'Exit Sign', 'Fire Exit',
    'Chair', 'Table', 'Desk', 'Monitor', 'Keyboard', 'Mouse', 'Printer',
    'Building', 'Pillar', 'Ceiling', 'Floor', 'Stairs', 'Elevator', 'Escalator',
    'Fire Extinguisher', 'Emergency Button', 'Alarm', 'Light', 'Fence', 'Gate'
  ],
  
  detectObjects: (imageData: ImageData): DetectionResult[] => {
    const mockDetections: DetectionResult[] = [
      {
        object: 'Person',
        confidence: 0.92,
        bbox: { x: 150, y: 100, width: 80, height: 150 },
        type: 'normal'
      },
      {
        object: 'Mobile Phone',
        confidence: 0.89,
        bbox: { x: 180, y: 90, width: 25, height: 45 },
        type: 'device'
      },
      {
        object: 'CCTV',
        confidence: 0.95,
        bbox: { x: 50, y: 20, width: 40, height: 30 },
        type: 'device'
      },
      {
        object: 'Wall',
        confidence: 0.97,
        bbox: { x: 0, y: 0, width: 80, height: 300 },
        type: 'structure'
      },
      {
        object: 'Door',
        confidence: 0.91,
        bbox: { x: 320, y: 100, width: 50, height: 150 },
        type: 'structure'
      },
      {
        object: 'Exit Sign',
        confidence: 0.88,
        bbox: { x: 300, y: 50, width: 60, height: 30 },
        type: 'normal'
      },
      {
        object: 'Suspicious activity',
        confidence: 0.76,
        bbox: { x: 250, y: 80, width: 100, height: 120 },
        type: 'suspicious'
      },
      {
        object: 'Abandoned object',
        confidence: 0.84,
        bbox: { x: 280, y: 200, width: 40, height: 30 },
        type: 'suspicious'
      },
      {
        object: 'Car',
        confidence: 0.94,
        bbox: { x: 100, y: 250, width: 150, height: 80 },
        type: 'normal'
      },
      {
        object: 'Monitor',
        confidence: 0.86,
        bbox: { x: 200, y: 120, width: 60, height: 40 },
        type: 'device'
      }
    ];
    
    return mockDetections.map(detection => ({
      ...detection,
      bbox: {
        ...detection.bbox,
        x: Math.random() * (imageData.width - detection.bbox.width),
        y: Math.random() * (imageData.height - detection.bbox.height)
      }
    }));
  }
};

export const generalModel = {
  classes: [
    'Person', 'Mobile Phone', 'Laptop', 'Tablet', 'Computer', 'Monitor', 'Keyboard', 'Mouse',
    'Wall', 'Door', 'Window', 'Ceiling', 'Floor', 'Stairs', 'Elevator',
    'Car', 'Bicycle', 'Motorcycle', 'Bus', 'Truck', 'Van', 'Taxi',
    'Traffic light', 'Stop sign', 'Speed limit sign', 'No parking sign', 'Street sign',
    'Chair', 'Table', 'Desk', 'Sofa', 'Bed', 'Cabinet', 'Shelf', 'Bookshelf',
    'TV', 'Radio', 'Speaker', 'Headphones', 'Phone', 'Clock', 'Watch',
    'Bag', 'Backpack', 'Suitcase', 'Umbrella', 'Bottle', 'Cup', 'Glass',
    'Book', 'Newspaper', 'Magazine', 'Pen', 'Pencil', 'Paper', 'Notebook',
    'Plant', 'Tree', 'Flower', 'Grass', 'Building', 'House', 'Office',
    'Light', 'Lamp', 'Fan', 'Air conditioner', 'Heater', 'Fire extinguisher',
    'Camera', 'Printer', 'Scanner', 'Projector', 'Microphone', 'Cable'
  ],
  
  detectObjects: (imageData: ImageData): DetectionResult[] => {
    const mockDetections: DetectionResult[] = [
      {
        object: 'Person',
        confidence: 0.91,
        bbox: { x: 100, y: 120, width: 70, height: 140 },
        type: 'normal'
      },
      {
        object: 'Mobile Phone',
        confidence: 0.88,
        bbox: { x: 130, y: 100, width: 25, height: 45 },
        type: 'device'
      },
      {
        object: 'Laptop',
        confidence: 0.94,
        bbox: { x: 200, y: 160, width: 80, height: 50 },
        type: 'device'
      },
      {
        object: 'Wall',
        confidence: 0.96,
        bbox: { x: 0, y: 0, width: 100, height: 400 },
        type: 'structure'
      },
      {
        object: 'Chair',
        confidence: 0.85,
        bbox: { x: 180, y: 200, width: 50, height: 80 },
        type: 'normal'
      },
      {
        object: 'Table',
        confidence: 0.89,
        bbox: { x: 150, y: 180, width: 100, height: 60 },
        type: 'normal'
      },
      {
        object: 'Monitor',
        confidence: 0.92,
        bbox: { x: 170, y: 140, width: 60, height: 40 },
        type: 'device'
      },
      {
        object: 'Keyboard',
        confidence: 0.87,
        bbox: { x: 175, y: 185, width: 50, height: 15 },
        type: 'device'
      },
      {
        object: 'Door',
        confidence: 0.90,
        bbox: { x: 320, y: 50, width: 40, height: 150 },
        type: 'structure'
      },
      {
        object: 'Light',
        confidence: 0.83,
        bbox: { x: 200, y: 20, width: 40, height: 20 },
        type: 'normal'
      },
      {
        object: 'Bag',
        confidence: 0.86,
        bbox: { x: 250, y: 220, width: 40, height: 50 },
        type: 'normal'
      },
      {
        object: 'Bottle',
        confidence: 0.81,
        bbox: { x: 220, y: 170, width: 15, height: 30 },
        type: 'normal'
      }
    ];
    
    return mockDetections.map(detection => ({
      ...detection,
      bbox: {
        ...detection.bbox,
        x: Math.random() * (imageData.width - detection.bbox.width),
        y: Math.random() * (imageData.height - detection.bbox.height)
      }
    }));
  }
};

export const processVideoFrame = (
  canvas: HTMLCanvasElement,
  model: 'construction' | 'security' | 'general'
): DetectionResult[] => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return [];
  
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  
  switch (model) {
    case 'construction':
      return constructionSafetyModel.detectObjects(imageData);
    case 'security':
      return securityModel.detectObjects(imageData);
    case 'general':
      return generalModel.detectObjects(imageData);
    default:
      return [];
  }
};
