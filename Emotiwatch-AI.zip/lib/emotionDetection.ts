export interface EmotionScores {
  happy: number;
  sad: number;
  angry: number;
  surprised: number;
  fearful: number;
  disgusted: number;
  neutral: number;
}

export interface FaceDetection {
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  emotions: EmotionScores;
  dominantEmotion: string;
  confidence: number;
}

export class EmotionRecognitionModel {
  private initialized = false;

  async initialize(): Promise<void> {
    // Simulate model initialization
    await new Promise(resolve => setTimeout(resolve, 1000));
    this.initialized = true;
  }

  async detectEmotions(imageData: ImageData): Promise<FaceDetection[]> {
    if (!this.initialized) {
      throw new Error('Model not initialized');
    }

    // Simulate face detection and emotion recognition
    const numFaces = Math.floor(Math.random() * 3) + 1;
    const detections: FaceDetection[] = [];

    for (let i = 0; i < numFaces; i++) {
      const emotions: EmotionScores = {
        happy: Math.random() * 0.8 + 0.1,
        sad: Math.random() * 0.6 + 0.05,
        angry: Math.random() * 0.5 + 0.05,
        surprised: Math.random() * 0.4 + 0.05,
        fearful: Math.random() * 0.3 + 0.02,
        disgusted: Math.random() * 0.3 + 0.02,
        neutral: Math.random() * 0.7 + 0.1
      };

      // Normalize emotions to sum to 1
      const total = Object.values(emotions).reduce((sum, val) => sum + val, 0);
      Object.keys(emotions).forEach(key => {
        emotions[key as keyof EmotionScores] /= total;
      });

      const dominantEmotion = Object.entries(emotions).reduce((a, b) => 
        emotions[a[0] as keyof EmotionScores] > emotions[b[0] as keyof EmotionScores] ? a : b
      )[0];

      const detection: FaceDetection = {
        bbox: {
          x: Math.random() * (imageData.width - 120),
          y: Math.random() * (imageData.height - 150),
          width: 120 + Math.random() * 60,
          height: 150 + Math.random() * 70
        },
        emotions,
        dominantEmotion,
        confidence: emotions[dominantEmotion as keyof EmotionScores]
      };

      detections.push(detection);
    }

    return detections;
  }

  async analyzeVideoFrame(canvas: HTMLCanvasElement): Promise<FaceDetection[]> {
    const ctx = canvas.getContext('2d');
    if (!ctx) return [];

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    return await this.detectEmotions(imageData);
  }
}

export const emotionModel = new EmotionRecognitionModel();

export const emotionLabels = {
  happy: 'Happy',
  sad: 'Sad',
  angry: 'Angry',
  surprised: 'Surprised',
  fearful: 'Fearful',
  disgusted: 'Disgusted',
  neutral: 'Neutral'
};

export const emotionColors = {
  happy: '#10b981',
  sad: '#3b82f6',
  angry: '#ef4444',
  surprised: '#f59e0b',
  fearful: '#8b5cf6',
  disgusted: '#84cc16',
  neutral: '#6b7280'
};

export const processEmotionData = (detections: FaceDetection[]) => {
  if (detections.length === 0) return null;

  const emotionTotals: { [key: string]: number } = {};
  const emotionCounts: { [key: string]: number } = {};

  detections.forEach(detection => {
    emotionCounts[detection.dominantEmotion] = (emotionCounts[detection.dominantEmotion] || 0) + 1;
    
    Object.entries(detection.emotions).forEach(([emotion, value]) => {
      emotionTotals[emotion] = (emotionTotals[emotion] || 0) + value;
    });
  });

  const totalDetections = detections.length;
  const averageEmotions = Object.entries(emotionTotals).map(([emotion, total]) => ({
    emotion,
    percentage: (total / totalDetections) * 100
  })).sort((a, b) => b.percentage - a.percentage);

  const dominantEmotions = Object.entries(emotionCounts).map(([emotion, count]) => ({
    emotion,
    count,
    percentage: (count / totalDetections) * 100
  })).sort((a, b) => b.count - a.count);

  const avgConfidence = detections.reduce((sum, d) => sum + d.confidence, 0) / totalDetections;

  return {
    totalDetections,
    averageEmotions,
    dominantEmotions,
    avgConfidence: avgConfidence * 100
  };
};