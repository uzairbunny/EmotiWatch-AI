import { translateWithOpenAI } from './openai';

export async function translateText(text: string, sourceLang: string, targetLang: string): Promise<string> {
  try {
    // First try OpenAI for better medical translation
    try {
      return await translateWithOpenAI(text, sourceLang, targetLang);
    } catch (openaiError) {
      console.warn('OpenAI translation failed, falling back to MyMemory:', openaiError);
    }

    // Fallback to MyMemory API
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${sourceLang}|${targetLang}`;
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error('Translation service unavailable');
    }

    const data = await response.json();
    
    if (data.responseStatus === 200) {
      return data.responseData.translatedText;
    } else {
      throw new Error('Translation service error');
    }
  } catch (error) {
    console.error('Translation error:', error);
    
    // Final fallback - return original text with error indication
    return `[Translation Error] ${text}`;
  }
}