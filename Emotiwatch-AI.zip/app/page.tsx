
'use client';

import { Suspense } from 'react';
import Header from '@/components/Header';
import EmotionInterface from '@/components/EmotionInterface';
import ErrorBoundary from '@/components/ErrorBoundary';

export default function Home() {
  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100">
        <Header />
        
        <main className="container mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              EmotiWatch AI
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Advanced Facial Emotion Recognition System - Real-time emotion detection from live video feeds using AI-powered facial analysis
            </p>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-8 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              <div className="p-4">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="ri-emotion-happy-line text-2xl text-white"></i>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Real-time Detection</h3>
                <p className="text-gray-600">Instant emotion analysis from live camera feeds</p>
              </div>
              
              <div className="p-4">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-teal-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="ri-brain-line text-2xl text-white"></i>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">AI-Powered Analysis</h3>
                <p className="text-gray-600">Advanced neural networks for accurate emotion recognition</p>
              </div>
              
              <div className="p-4">
                <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="ri-bar-chart-line text-2xl text-white"></i>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Emotion Analytics</h3>
                <p className="text-gray-600">Comprehensive emotion tracking and analysis</p>
              </div>
            </div>
          </div>

          <Suspense fallback={<div className="text-center">Loading emotion recognition system...</div>}>
            <EmotionInterface />
          </Suspense>
        </main>
      </div>
    </ErrorBoundary>
  );
}
